#pragma once

#include "fix_engine/fix_message.h"
#include "fix_engine/fix_session_manager.h"
#include <atomic>
#include <memory>
#include <string>
#include <thread>

namespace fix_gateway {
namespace shadow_engine {

const char* redpandaDefaultOffsetReset();

class RedPandaIngress {
public:
    explicit RedPandaIngress(fix_engine::FIXSessionManager& sessionManager);
    ~RedPandaIngress();

    bool start();
    void stop();

private:
    void consumeLoop();
    void routeMessage(const std::string& rawMessage);
    void normalizeIngressMessage(fix_engine::FIXMessage& message) const;

    fix_engine::FIXSessionManager& sessionManager_;
    std::atomic<bool> running_{false};
    std::thread worker_;

    class RdKafkaConsumer;
    std::unique_ptr<RdKafkaConsumer> consumer_;
};

} // namespace shadow_engine
} // namespace fix_gateway