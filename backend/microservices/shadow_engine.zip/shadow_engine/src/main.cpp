#include "fix_engine/fix_session_manager.h"
#include "shadow_engine/redpanda_ingress.h"
#include "shadow_engine/telemetry_bridge.h"
#include "utils/logger.h"
#include "utils/config_loader.h"
#include <iostream>
#include <csignal>
#include <atomic>
#include <cstdlib>

std::atomic<bool> g_running{true};

void signalHandler(int signal) {
    if (signal == SIGINT || signal == SIGTERM) {
        g_running = false;
    }
}

int main(int argc, char* argv[]) {
    using namespace fix_gateway;
    
    std::signal(SIGINT, signalHandler);
    std::signal(SIGTERM, signalHandler);
    
    try {
        auto& logger = utils::Logger::getInstance();
        logger.initialize("logs");
        auto mainLogger = logger.getLogger("main");
        mainLogger->info("FIX Trading Gateway starting...");
        
        std::string configPath = "config/fix_config.json";
        if (argc > 1) {
            configPath = argv[1];
        }
        
        auto& configLoader = utils::ConfigLoader::getInstance();
        if (!configLoader.loadConfig(configPath)) {
            mainLogger->error("Failed to load configuration");
            return 1;
        }
        
        std::string rulesPath = "config/trading_rules.json";
        if (!configLoader.loadTradingRules(rulesPath)) {
            mainLogger->warn("Failed to load trading rules, using defaults");
        }
        
        auto sessions = configLoader.getSessions();
        if (sessions.empty()) {
            mainLogger->error("No sessions configured");
            return 1;
        }
        
        mainLogger->info("FIX session startup remains disabled; keeping the shadow telemetry listener active.");

        auto& sessionManager = fix_engine::FIXSessionManager::getInstance();
        sessionManager.initialize(sessions);

        fix_gateway::shadow_engine::TelemetryBridge telemetryBridge;
        const std::string telemetryHost = ::getenv("TELEMETRY_HOST") ? ::getenv("TELEMETRY_HOST") : "0.0.0.0";
        const unsigned short telemetryPort = static_cast<unsigned short>(
            std::stoi(::getenv("TELEMETRY_PORT") ? ::getenv("TELEMETRY_PORT") : "9100"));

        sessionManager.setExecutionReportSink([&telemetryBridge](const fix_engine::FIXMessage& report) {
            telemetryBridge.onExecutionReport(report);
        });

        if (!telemetryBridge.start(telemetryHost, telemetryPort)) {
            mainLogger->error("Shadow telemetry listener could not be started");
            return 1;
        }

        fix_gateway::shadow_engine::RedPandaIngress redpandaIngress(sessionManager);
        if (!redpandaIngress.start()) {
            mainLogger->info("Shadow Redpanda ingress will remain disabled until REDPANDA_BROKERS/REDPANDA_TOPIC are configured");
        }

        sessionManager.startExecutionOnly();

        mainLogger->info("Shadow service is running with Redpanda input and TCP egress enabled; FIX session processing stays disabled.");
        
        while (g_running) {
            std::this_thread::sleep_for(std::chrono::seconds(1));
        }
        
        mainLogger->info("Shutdown signal received");
        mainLogger->info("Shadow service stopped");
        
    } catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << std::endl;
        return 1;
    }
    
    return 0;
}
