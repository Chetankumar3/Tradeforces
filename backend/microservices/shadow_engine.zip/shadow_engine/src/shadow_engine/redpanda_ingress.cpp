#include "shadow_engine/redpanda_ingress.h"

#include "utils/logger.h"

#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <sstream>

#if __has_include("librdkafka/rdkafkacpp.h")
#include <librdkafka/rdkafkacpp.h>
#endif

namespace fix_gateway {
namespace shadow_engine {

namespace {
std::string getenv_or(const char* name, const std::string& fallback) {
    const char* value = ::getenv(name);
    return value ? std::string(value) : fallback;
}

std::string currentTimestamp() {
    const auto now = std::chrono::system_clock::now();
    const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
    auto time = std::chrono::system_clock::to_time_t(now);
    std::tm tm{};
#if defined(_WIN32)
    gmtime_s(&tm, &time);
#else
    gmtime_r(&time, &tm);
#endif
    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y%m%d-%H:%M:%S") << '.' << std::setw(3) << std::setfill('0') << ms.count();
    return oss.str();
}
} // namespace

#if __has_include("librdkafka/rdkafkacpp.h")
class RedPandaIngress::RdKafkaConsumer {
public:
    explicit RdKafkaConsumer(const std::string& brokers,
                             const std::string& topic,
                             const std::string& groupId,
                             const std::string& username,
                             const std::string& password,
                             const std::string& mechanism) {
        std::string err;
        auto* conf = RdKafka::Conf::create(RdKafka::Conf::CONF_GLOBAL);
        if (conf->set("bootstrap.servers", brokers, err) != RdKafka::Conf::CONF_OK) {
            throw std::runtime_error("Failed to set bootstrap.servers: " + err);
        }
        if (conf->set("group.id", groupId, err) != RdKafka::Conf::CONF_OK) {
            throw std::runtime_error("Failed to set group.id: " + err);
        }
        if (!username.empty()) {
            conf->set("security.protocol", "SASL_SSL", err);
            conf->set("sasl.mechanism", mechanism, err);
            conf->set("sasl.username", username, err);
            conf->set("sasl.password", password, err);
        }

        consumer_.reset(RdKafka::Consumer::create(conf, err));
        if (!consumer_) {
            throw std::runtime_error("Failed to create Kafka consumer: " + err);
        }

        delete conf;

        RdKafka::ErrorCode ec = consumer_->subscribe({topic});
        if (ec != RdKafka::ERR_NO_ERROR) {
            throw std::runtime_error("Failed to subscribe: " + RdKafka::err2str(ec));
        }
    }

    bool poll(std::string& value) {
        RdKafka::Message* msg = consumer_->consume(1000);
        if (!msg) {
            return false;
        }

        if (msg->err() == RdKafka::ERR_NO_ERROR) {
            const auto* payload = static_cast<const char*>(msg->payload());
            const auto len = static_cast<size_t>(msg->len());
            value.assign(payload, len);
            delete msg;
            return true;
        }

        delete msg;
        return false;
    }

private:
    std::unique_ptr<RdKafka::Consumer> consumer_;
};
#endif

RedPandaIngress::RedPandaIngress(fix_engine::FIXSessionManager& sessionManager)
    : sessionManager_(sessionManager) {}

RedPandaIngress::~RedPandaIngress() {
    stop();
}

bool RedPandaIngress::start() {
    if (running_) {
        return true;
    }

    const std::string brokers = getenv_or("REDPANDA_BROKERS", "");
    const std::string topic = getenv_or("REDPANDA_TOPIC", "");
    if (brokers.empty() || topic.empty()) {
        utils::Logger::getInstance().getLogger("main")->info(
            "Redpanda ingress disabled: REDPANDA_BROKERS/REDPANDA_TOPIC not set");
        return false;
    }

    running_ = true;

#if __has_include("librdkafka/rdkafkacpp.h")
    try {
        const std::string groupId = getenv_or("REDPANDA_GROUP_ID", "shadow-engine-group");
        const std::string username = getenv_or("REDPANDA_USERNAME", "");
        const std::string password = getenv_or("REDPANDA_PASSWORD", "");
        const std::string mechanism = getenv_or("REDPANDA_SASL_MECHANISM", "SCRAM-SHA256");

        consumer_ = std::make_unique<RdKafkaConsumer>(brokers, topic, groupId, username, password, mechanism);
        worker_ = std::thread([this]() { consumeLoop(); });

        utils::Logger::getInstance().getLogger("main")->info(
            "Redpanda ingress consumer started for topic " + topic);
        return true;
    } catch (const std::exception& ex) {
        utils::Logger::getInstance().getLogger("main")->error(
            std::string("Redpanda ingress setup failed: ") + ex.what());
        running_ = false;
        return false;
    }
#else
    utils::Logger::getInstance().getLogger("main")->warn(
        "Redpanda ingress disabled: librdkafka headers are not available in this build");
    running_ = false;
    return false;
#endif
}

void RedPandaIngress::stop() {
    if (!running_) {
        return;
    }

    running_ = false;
    if (worker_.joinable()) {
        worker_.join();
    }
}

void RedPandaIngress::consumeLoop() {
    while (running_) {
        std::string rawMessage;

#if __has_include("librdkafka/rdkafkacpp.h")
        if (consumer_ && consumer_->poll(rawMessage)) {
            routeMessage(rawMessage);
        }
#else
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
#endif
    }
}

void RedPandaIngress::routeMessage(const std::string& rawMessage) {
    fix_engine::FIXMessage message;
    if (!message.parse(rawMessage)) {
        utils::Logger::getInstance().getLogger("main")->warn(
            "Skipping invalid Redpanda FIX message; raw length=" + std::to_string(rawMessage.size()));
        return;
    }

    normalizeIngressMessage(message);

    const std::string sessionId = getenv_or("SHADOW_ENGINE_SESSION_ID", "");
    std::shared_ptr<order_manager::OrderManager> orderManager;

    if (!sessionId.empty()) {
        orderManager = sessionManager_.getOrderManager(sessionId);
    } else {
        const auto sessionIds = sessionManager_.getSessionIds();
        if (!sessionIds.empty()) {
            orderManager = sessionManager_.getOrderManager(sessionIds.front());
        }
    }

    if (!orderManager) {
        utils::Logger::getInstance().getLogger("main")->warn(
            "No FIX session available for Redpanda ingress");
        return;
    }

    switch (message.getMsgType()) {
        case fix_engine::MsgType::NEW_ORDER_SINGLE:
            orderManager->handleNewOrderSingle(message);
            break;
        case fix_engine::MsgType::ORDER_CANCEL_REQUEST:
            orderManager->handleOrderCancelRequest(message);
            break;
        case fix_engine::MsgType::ORDER_CANCEL_REPLACE_REQUEST:
            orderManager->handleOrderCancelReplaceRequest(message);
            break;
        default:
            utils::Logger::getInstance().getLogger("main")->warn(
                "Ignoring unsupported Redpanda FIX message type");
            break;
    }
}

void RedPandaIngress::normalizeIngressMessage(fix_engine::FIXMessage& message) const {
    if (!message.hasField(8)) {
        message.setField(8, "FIX.4.2");
    }

    if (!message.hasField(49)) {
        message.setField(49, getenv_or("FIX_SENDER_COMP_ID", "SHADOW_ENGINE"));
    }
    if (!message.hasField(56)) {
        message.setField(56, getenv_or("FIX_TARGET_COMP_ID", "TELEMETRY"));
    }
    if (!message.hasField(34)) {
        message.setField(34, "1");
    }
    if (!message.hasField(52)) {
        message.setField(52, currentTimestamp());
    }

    if (!message.hasField(11) && message.getMsgType() == fix_engine::MsgType::ORDER_CANCEL_REQUEST) {
        message.setField(11, "0");
    }
}

} // namespace shadow_engine
} // namespace fix_gateway
