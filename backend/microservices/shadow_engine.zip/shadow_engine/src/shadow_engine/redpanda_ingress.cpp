#include "shadow_engine/redpanda_ingress.h"

#include "utils/logger.h"

#include <chrono>
#include <cstdlib>
#include <iomanip>
#include <sstream>

#include <librdkafka/rdkafkacpp.h>

namespace fix_gateway {
namespace shadow_engine {

namespace {
std::string getenv_or(const char* name, const std::string& fallback) {
    const char* value = ::getenv(name);
    return value ? std::string(value) : fallback;
}

std::string currentTimestamp() {
    const auto now = std::chrono::system_clock::now();
    const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;
    auto time = std::chrono::system_clock::to_time_t(now);
    std::tm tm{};
#if defined(_WIN32)
    gmtime_s(&tm, &time);
#else
    gmtime_r(&time, &tm);
#endif
    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y%m%d-%H:%M:%S") << '.' << std::setw(3) << std::setfill('0') << ms.count();
    return oss.str();
}

// Renders a raw payload as a printable preview, with SOH (0x01) shown as '|'
// so FIX messages are readable in logs, and non-printable bytes hex-escaped.
std::string previewPayload(const std::string& raw, size_t maxLen = 200) {
    std::ostringstream oss;
    const size_t n = std::min(raw.size(), maxLen);
    for (size_t i = 0; i < n; ++i) {
        const unsigned char c = static_cast<unsigned char>(raw[i]);
        if (c == 0x01) {
            oss << '|';
        } else if (c >= 0x20 && c < 0x7f) {
            oss << static_cast<char>(c);
        } else {
            oss << "\\x" << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(c) << std::dec;
        }
    }
    if (raw.size() > maxLen) {
        oss << "...(truncated, total=" << raw.size() << " bytes)";
    }
    return oss.str();
}
} // namespace

const char* redpandaDefaultOffsetReset() {
    return "earliest";
}


namespace {

// Surfaces low-level librdkafka errors (auth failures, broker connectivity,
// SASL/TLS issues, etc.) that would otherwise be invisible because the
// high-level consume() API only reports errors per-message.
class IngressEventCb : public RdKafka::EventCb {
public:
    void event_cb(RdKafka::Event& event) override {
        auto logger = utils::Logger::getInstance().getLogger("main");
        switch (event.type()) {
            case RdKafka::Event::EVENT_ERROR:
                logger->error("[shadow redpanda] librdkafka error (" +
                               RdKafka::err2str(event.err()) + "): " + event.str() +
                               (event.fatal() ? " [FATAL]" : ""));
                break;
            case RdKafka::Event::EVENT_LOG:
                logger->info("[shadow redpanda] librdkafka log: " + event.str());
                break;
            case RdKafka::Event::EVENT_STATS:
                // Too noisy for info-level; uncomment if deep debugging is needed.
                // logger->debug("[shadow redpanda] stats: " + event.str());
                break;
            default:
                break;
        }
    }
};

// Logs partition assignment/revocation so we can confirm the consumer group
// actually got assigned partitions, and (optionally) overrides the starting
// offset on assignment. This is the escape hatch for the common case where
// `auto.offset.reset=earliest` is silently ignored because the consumer
// group already has committed offsets sitting past the end of the backlog.
//
// Set REDPANDA_FORCE_OFFSET_RESET=earliest|latest to force a position on
// every (re)assignment, bypassing any previously committed offsets.
class IngressRebalanceCb : public RdKafka::RebalanceCb {
public:
    void rebalance_cb(RdKafka::KafkaConsumer* consumer, RdKafka::ErrorCode err,
                       std::vector<RdKafka::TopicPartition*>& partitions) override {
        auto logger = utils::Logger::getInstance().getLogger("main");

        if (err == RdKafka::ERR__ASSIGN_PARTITIONS) {
            const std::string forceReset = getenv_or("REDPANDA_FORCE_OFFSET_RESET", "");
            if (forceReset == "earliest") {
                for (auto* tp : partitions) {
                    tp->set_offset(RdKafka::Topic::OFFSET_BEGINNING);
                }
                logger->info("[shadow redpanda] REDPANDA_FORCE_OFFSET_RESET=earliest: "
                              "seeking all assigned partitions to the beginning");
            } else if (forceReset == "latest") {
                for (auto* tp : partitions) {
                    tp->set_offset(RdKafka::Topic::OFFSET_END);
                }
                logger->info("[shadow redpanda] REDPANDA_FORCE_OFFSET_RESET=latest: "
                              "seeking all assigned partitions to the end");
            }

            for (auto* tp : partitions) {
                logger->info("[shadow redpanda] partition assigned: " + tp->topic() + "[" +
                              std::to_string(tp->partition()) + "] starting offset=" +
                              std::to_string(tp->offset()));
            }

            const RdKafka::ErrorCode assignErr = consumer->assign(partitions);
            if (assignErr != RdKafka::ERR_NO_ERROR) {
                logger->error("[shadow redpanda] assign() failed: " + RdKafka::err2str(assignErr));
            }
        } else if (err == RdKafka::ERR__REVOKE_PARTITIONS) {
            logger->info("[shadow redpanda] partitions revoked (rebalance)");
            consumer->unassign();
        } else {
            logger->error("[shadow redpanda] rebalance error: " + RdKafka::err2str(err));
        }
    }
};

} // namespace

class RedPandaIngress::RdKafkaConsumer {
public:
    explicit RdKafkaConsumer(const std::string& brokers,
                             const std::string& topic,
                             const std::string& groupId,
                             const std::string& username,
                             const std::string& password,
                             const std::string& mechanism) {
        auto logger = utils::Logger::getInstance().getLogger("main");

        std::string err;
        auto* conf = RdKafka::Conf::create(RdKafka::Conf::CONF_GLOBAL);
        if (conf->set("bootstrap.servers", brokers, err) != RdKafka::Conf::CONF_OK) {
            throw std::runtime_error("Failed to set bootstrap.servers: " + err);
        }
        if (conf->set("group.id", groupId, err) != RdKafka::Conf::CONF_OK) {
            throw std::runtime_error("Failed to set group.id: " + err);
        }
        if (conf->set("auto.offset.reset", redpandaDefaultOffsetReset(), err) != RdKafka::Conf::CONF_OK) {
            throw std::runtime_error("Failed to set auto.offset.reset: " + err);
        }
        if (conf->set("enable.auto.commit", "true", err) != RdKafka::Conf::CONF_OK) {
            throw std::runtime_error("Failed to set enable.auto.commit: " + err);
        }

        // Surface low-level connection/auth errors instead of silently
        // failing every poll().
        if (conf->set("event_cb", &eventCb_, err) != RdKafka::Conf::CONF_OK) {
            throw std::runtime_error("Failed to set event_cb: " + err);
        }
        // Log partition assignment and allow forcing an offset reset to
        // bypass stuck committed offsets (see REDPANDA_FORCE_OFFSET_RESET).
        if (conf->set("rebalance_cb", &rebalanceCb_, err) != RdKafka::Conf::CONF_OK) {
            throw std::runtime_error("Failed to set rebalance_cb: " + err);
        }

        if (!username.empty()) {
            if (conf->set("security.protocol", "SASL_SSL", err) != RdKafka::Conf::CONF_OK) {
                throw std::runtime_error("Failed to set security.protocol: " + err);
            }
            if (conf->set("sasl.mechanism", mechanism, err) != RdKafka::Conf::CONF_OK) {
                throw std::runtime_error("Failed to set sasl.mechanism: " + err);
            }
            if (conf->set("sasl.username", username, err) != RdKafka::Conf::CONF_OK) {
                throw std::runtime_error("Failed to set sasl.username: " + err);
            }
            if (conf->set("sasl.password", password, err) != RdKafka::Conf::CONF_OK) {
                throw std::runtime_error("Failed to set sasl.password: " + err);
            }
        }

        consumer_.reset(RdKafka::KafkaConsumer::create(conf, err));
        if (!consumer_) {
            throw std::runtime_error("Failed to create Kafka consumer: " + err);
        }

        delete conf;

        RdKafka::ErrorCode ec = consumer_->subscribe({topic});
        if (ec != RdKafka::ERR_NO_ERROR) {
            throw std::runtime_error("Failed to subscribe: " + RdKafka::err2str(ec));
        }

        logger->info("[shadow redpanda] subscribed to topic='" + topic + "' group.id='" + groupId +
                      "' security.protocol=" + (username.empty() ? "PLAINTEXT" : "SASL_SSL(" + mechanism + ")") +
                      " auto.offset.reset=" + std::string(redpandaDefaultOffsetReset()));
    }

    ~RdKafkaConsumer() {
        if (consumer_) {
            consumer_->close();
        }
    }

    // Returns true if a message payload was placed in `value`. Returns
    // false on timeout, EOF, or error (errors are logged here so they're
    // no longer silently dropped).
    bool poll(std::string& value) {
        std::unique_ptr<RdKafka::Message> msg(consumer_->consume(1000));
        if (!msg) {
            return false;
        }

        switch (msg->err()) {
            case RdKafka::ERR_NO_ERROR: {
                const auto* payload = static_cast<const char*>(msg->payload());
                const auto len = static_cast<size_t>(msg->len());
                value.assign(payload, len);
                return true;
            }
            case RdKafka::ERR__TIMED_OUT:
                // Normal: no message available within the poll timeout.
                return false;
            case RdKafka::ERR__PARTITION_EOF:
                // Normal: reached the end of the partition (consumer is
                // caught up). Not an error.
                return false;
            default: {
                auto logger = utils::Logger::getInstance().getLogger("main");
                std::string detail = RdKafka::err2str(msg->err());
                if (!msg->errstr().empty()) {
                    detail += " (" + msg->errstr() + ")";
                }
                logger->error("[shadow redpanda] consume() error: " + detail);
                return false;
            }
        }
    }

private:
    IngressEventCb eventCb_;
    IngressRebalanceCb rebalanceCb_;
    std::unique_ptr<RdKafka::KafkaConsumer> consumer_;
};

RedPandaIngress::RedPandaIngress(fix_engine::FIXSessionManager& sessionManager)
    : sessionManager_(sessionManager) {}

RedPandaIngress::~RedPandaIngress() {
    stop();
}

bool RedPandaIngress::start() {
    if (running_) {
        return true;
    }

    auto logger = utils::Logger::getInstance().getLogger("main");

    const std::string brokers = getenv_or("REDPANDA_BOOTSTRAP_SERVERS", "");
    const std::string topic = getenv_or("REDPANDA_ORDERS_TOPIC", "");
    if (brokers.empty() || topic.empty()) {
        logger->info(
            "Redpanda ingress disabled: REDPANDA_BOOTSTRAP_SERVERS/REDPANDA_ORDERS_TOPIC not set");
        return false;
    }

    logger->info("[shadow redpanda] starting ingress: brokers='" + brokers + "' topic='" + topic + "'");

    running_ = true;

    try {
        const std::string groupId = getenv_or("REDPANDA_GROUP_ID", "shadow-engine-group");
        const std::string username = getenv_or("REDPANDA_SASL_USERNAME", "");
        const std::string password = getenv_or("REDPANDA_SASL_PASSWORD", "");
        const std::string mechanism = getenv_or("REDPANDA_SASL_MECHANISM", "SCRAM-SHA256");

        consumer_ = std::make_unique<RdKafkaConsumer>(brokers, topic, groupId, username, password, mechanism);
        worker_ = std::thread([this]() { consumeLoop(); });

        logger->info("Redpanda ingress consumer started for topic " + topic);
        return true;
    } catch (const std::exception& ex) {
        logger->error(std::string("Redpanda ingress setup failed: ") + ex.what());
        running_ = false;
        return false;
    }
    logger->warn("Redpanda ingress disabled: librdkafka headers are not available in this build");
    running_ = false;
    return false;
}

void RedPandaIngress::stop() {
    if (!running_) {
        return;
    }

    running_ = false;
    if (worker_.joinable()) {
        worker_.join();
    }
}

void RedPandaIngress::consumeLoop() {
    auto logger = utils::Logger::getInstance().getLogger("main");
    uint64_t messagesReceived = 0;

    while (running_) {
        std::string rawMessage;

        if (consumer_ && consumer_->poll(rawMessage)) {
            ++messagesReceived;
            if (messagesReceived <= 5 || messagesReceived % 1000 == 0) {
                logger->info("[shadow redpanda] received message #" + std::to_string(messagesReceived) +
                              " (" + std::to_string(rawMessage.size()) + " bytes)");
            }
            routeMessage(rawMessage);
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
        
    }

    logger->info("[shadow redpanda] consume loop exiting; total messages received=" +
                  std::to_string(messagesReceived));
}

void RedPandaIngress::routeMessage(const std::string& rawMessage) {
    auto logger = utils::Logger::getInstance().getLogger("main");

    logger->info("[shadow redpanda] parse[0] rawLen=" + std::to_string(rawMessage.size()));

    fix_engine::FIXMessage message;
    if (!message.parse(rawMessage)) {
        logger->warn("Skipping invalid Redpanda FIX message; raw length=" + std::to_string(rawMessage.size()) +
                     ", preview=\"" + previewPayload(rawMessage) + "\"");
        return;
    }

    normalizeIngressMessage(message);

    const auto clOrdId = message.getField(11).value_or("<missing>");
    const auto symbol = message.getField(55).value_or("<missing>");
    logger->info("[shadow redpanda] parse[1] msgType=" + std::to_string(static_cast<int>(message.getMsgType())) +
                 ", ClOrdID=" + clOrdId + ", Symbol=" + symbol);

    const std::string sessionId = getenv_or("SHADOW_ENGINE_SESSION_ID", "");
    std::shared_ptr<order_manager::OrderManager> orderManager;

    if (!sessionId.empty()) {
        orderManager = sessionManager_.getOrderManager(sessionId);
    } else {
        const auto sessionIds = sessionManager_.getSessionIds();
        if (!sessionIds.empty()) {
            orderManager = sessionManager_.getOrderManager(sessionIds.front());
        }
    }

    if (!orderManager) {
        logger->warn("No FIX session available for Redpanda ingress");
        return;
    }

    logger->info("[shadow redpanda] parse[2] session=" + sessionId +
                 ", orderManager=ok, msgType=" + std::to_string(static_cast<int>(message.getMsgType())));

    switch (message.getMsgType()) {
        case fix_engine::MsgType::NEW_ORDER_SINGLE:
            logger->info("[shadow redpanda] parse[3] dispatch=NEW_ORDER_SINGLE");
            orderManager->handleNewOrderSingle(message);
            break;
        case fix_engine::MsgType::ORDER_CANCEL_REQUEST:
            logger->info("[shadow redpanda] parse[3] dispatch=ORDER_CANCEL_REQUEST");
            orderManager->handleOrderCancelRequest(message);
            break;
        case fix_engine::MsgType::ORDER_CANCEL_REPLACE_REQUEST:
            logger->info("[shadow redpanda] parse[3] dispatch=ORDER_CANCEL_REPLACE_REQUEST");
            orderManager->handleOrderCancelReplaceRequest(message);
            break;
        default:
            logger->warn("Ignoring unsupported Redpanda FIX message type (msgType=" +
                          std::to_string(static_cast<int>(message.getMsgType())) + ")");
            break;
    }
}

void RedPandaIngress::normalizeIngressMessage(fix_engine::FIXMessage& message) const {
    if (!message.hasField(8)) {
        message.setField(8, "FIX.4.2");
    }

    if (!message.hasField(49)) {
        message.setField(49, getenv_or("FIX_SENDER_COMP_ID", "SHADOW_ENGINE"));
    }
    if (!message.hasField(56)) {
        message.setField(56, getenv_or("FIX_TARGET_COMP_ID", "TELEMETRY"));
    }
    if (!message.hasField(34)) {
        message.setField(34, "1");
    }
    if (!message.hasField(52)) {
        message.setField(52, currentTimestamp());
    }

    if (!message.hasField(11) && message.getMsgType() == fix_engine::MsgType::ORDER_CANCEL_REQUEST) {
        message.setField(11, "0");
    }
}

} // namespace shadow_engine
} // namespace fix_gateway