#include "shadow_engine/redpanda_ingress.h"

#include <gtest/gtest.h>

namespace fix_gateway::shadow_engine {

TEST(RedPandaIngressConfig, UsesEarliestOffsetReset) {
    EXPECT_STREQ(redpandaDefaultOffsetReset(), "earliest");
}

} // namespace fix_gateway::shadow_engine
